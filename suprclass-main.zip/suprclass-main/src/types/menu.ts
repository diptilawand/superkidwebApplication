import { Key } from "react";

export type menuList = {
  id: Key;
  icon: any;
  title: string;
  link: string;
};
