declare module "imagekitio-react";
