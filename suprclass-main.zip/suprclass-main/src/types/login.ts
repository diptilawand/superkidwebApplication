export type User = {
  email?: string;
  password?: string;
};
