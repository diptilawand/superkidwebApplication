import storage from 'redux-persist/lib/storage'

const s = storage

export default s