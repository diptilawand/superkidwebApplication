import {
  Paper,
  TableBody,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { getAllStudentProfiles } from "../../../API/student-mgmt";
import { ERROR_TOAST } from "../../../helpers/toasters";
import "./addBatchStudents.css";

export default function AddBatchStudents(props: any) {
  const [studentRows, setStudentRows] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>(props.rows || []);
  const [rows, setRows] = useState([]);
  const [all, setAll] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleClick = () => {
    return props.handelClose();
  };

  useEffect(() => {
    getFirstData();
  }, []);

  const getFirstData = () => {
    getAllStudentProfiles()
      .then((data) => {
        if (!data) {
          setStudentRows([]);
          return ERROR_TOAST("error Connecting to Server !");
        }

        setStudentRows(data);
        setLoading(false);
      })
      .catch((e) => {
        return ERROR_TOAST("Something Wrong happend !");
      });
  };

  const onSelectAllClick = (e) => {
    // if (e.nativeEvent.target.checked) {
    //   setAll(true);
    //   studentRows.map((m: any) => {
    //     setSelected([m._id, ...selected]);
    //   });
    // } else {
    //   setAll(false);
    //   setSelected([]);
    // }
  };

  return (
    <>
      <div className="addBatchStudents">
        <div className="fullBatchDesc">
          <div className="headerACoach">
            <h2>Add Student</h2>
            <div
              className="top-svg"
              onClick={() => handleClick()}
              style={{ cursor: "pointer" }}
            >
              <svg
                width="30"
                height="30"
                viewBox="0 0 30 30"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 0C18.9782 0 22.7936 1.58035 25.6066 4.3934C28.4196 7.20644 30 11.0218 30 15C30 18.9782 28.4196 22.7936 25.6066 25.6066C22.7936 28.4196 18.9782 30 15 30C11.0218 30 7.20644 28.4196 4.3934 25.6066C1.58035 22.7936 0 18.9782 0 15C0 11.0218 1.58035 7.20644 4.3934 4.3934C7.20644 1.58035 11.0218 0 15 0ZM15 13.1807L11.5157 9.69643C11.2745 9.45518 10.9473 9.31964 10.6061 9.31964C10.2649 9.31964 9.93768 9.45518 9.69643 9.69643C9.45518 9.93768 9.31964 10.2649 9.31964 10.6061C9.31964 10.9473 9.45518 11.2745 9.69643 11.5157L13.1807 15L9.69643 18.4843C9.57697 18.6037 9.48221 18.7456 9.41757 18.9016C9.35292 19.0577 9.31964 19.225 9.31964 19.3939C9.31964 19.5629 9.35292 19.7301 9.41757 19.8862C9.48221 20.0423 9.57697 20.1841 9.69643 20.3036C9.81588 20.423 9.9577 20.5178 10.1138 20.5824C10.2699 20.6471 10.4371 20.6804 10.6061 20.6804C10.775 20.6804 10.9423 20.6471 11.0984 20.5824C11.2544 20.5178 11.3963 20.423 11.5157 20.3036L15 16.8193L18.4843 20.3036C18.6037 20.423 18.7456 20.5178 18.9016 20.5824C19.0577 20.6471 19.225 20.6804 19.3939 20.6804C19.5629 20.6804 19.7301 20.6471 19.8862 20.5824C20.0423 20.5178 20.1841 20.423 20.3036 20.3036C20.423 20.1841 20.5178 20.0423 20.5824 19.8862C20.6471 19.7301 20.6804 19.5629 20.6804 19.3939C20.6804 19.225 20.6471 19.0577 20.5824 18.9016C20.5178 18.7456 20.423 18.6037 20.3036 18.4843L16.8193 15L20.3036 11.5157C20.423 11.3963 20.5178 11.2544 20.5824 11.0984C20.6471 10.9423 20.6804 10.775 20.6804 10.6061C20.6804 10.4371 20.6471 10.2699 20.5824 10.1138C20.5178 9.9577 20.423 9.81588 20.3036 9.69643C20.1841 9.57697 20.0423 9.48221 19.8862 9.41757C19.7301 9.35292 19.5629 9.31964 19.3939 9.31964C19.225 9.31964 19.0577 9.35292 18.9016 9.41757C18.7456 9.48221 18.6037 9.57697 18.4843 9.69643L15 13.1807Z"
                  fill="#8E8EA1"
                />
              </svg>
            </div>
          </div>
          <div className="batch-student-border-top"></div>
          <div className="acoach-body">
            <div className="first-drop-batch">
              <div className="header">
                <button type="submit">search</button>
                <input
                  className="dashboard-search"
                  style={{
                    width: "100%",
                    borderWidth: "1px",
                    borderColor: "#C9C9D9",
                    background: "transparent",
                  }}
                  type="search"
                  placeholder="Search student..."
                />
              </div>
              <div className="table-for-batch-students">
                <TableContainer component={Paper}>
                  <Table sx={{ minWidth: 610 }} aria-label="simple table">
                    <TableHead>
                      <TableRow className="table-head-dashboard">
                        <TableCell>Student Name </TableCell>
                        <TableCell align="left">Gender</TableCell>
                        <TableCell align="left">Age</TableCell>
                        <TableCell padding="checkbox">
                          <Checkbox
                            // indeterminate={numSelected > 0 && numSelected < rowCount}
                            // checked={rowCount > 0 && numSelected === rowCount}
                            onChange={onSelectAllClick}
                            sx={{
                              color: "#B9B9D6",
                              "&.Mui-checked": {
                                color: "#EF1456",
                              },
                            }}
                            inputProps={{
                              "aria-label": "select all students",
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {studentRows.map((m: any) => (
                        <TableRow
                          style={
                            props.rows.indexOf(m._id) !== -1
                              ? { background: "#F2FBFF" }
                              : {}
                          }
                        >
                          <TableCell align="left">{m.name}</TableCell>
                          <TableCell align="left">{m.gender}</TableCell>
                          <TableCell align="left">{m.age + " Yrs"}</TableCell>
                          <TableCell padding="checkbox">
                            {/* {console.log()} */}
                            <Checkbox
                              value={m._id}
                              defaultChecked={
                                props.rows.indexOf(m._id) !== -1 ? true : false
                              }
                              key={m._id}
                              onChange={props.onSelect}
                              sx={{
                                color: "#B9B9D6",

                                "&.Mui-checked": {
                                  color: "#EF1456",
                                },
                              }}
                              inputProps={{
                                "aria-label": "select one",
                              }}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </div>
            </div>
          </div>
          <div className="drag-drop-top-line-batch"></div>
          <div className="down-buttons d-flex">
            <button className="create-button" onClick={props.handelSubmitPre}>
              Add Student
            </button>
            <button className="cancel-button" onClick={() => handleClick()}>
              Cancel
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
