import React from "react";
import SideBar from "../SideBar/SideBar"

export default function Batches() {
  return (
    <>  
    <div
      style={{
        height: "100vh",
        background: "red",
        width: "100%",
        marginLeft : '65px'
      }}
    >
      Batches
    </div>
    </>

  );
}
