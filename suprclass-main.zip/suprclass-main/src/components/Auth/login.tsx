import React, { useState } from "react";
import { LoginData } from "../../interface/loginInterface";
import "./login.css";
import { User } from "../../types/login";
import LoginMessage from "../../interface/loginInterface";
import mainLogo from "../../icons/logo.svg";


const Login = (props : LoginMessage) => {
  const [error, setError] = useState<String>("")
  const [show, setShow] = useState<Boolean>(true);
  const [user, setUser] = useState<User>({email : "", password : ""});


  const handelChange = (e : React.ChangeEvent<any>) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  } 

  const showData : any = () => {
    console.log(user);
  }

  return (
    <>
      <div className="background-login">
        <div className="card-login">
          <div className="top-login">
            <h2 className="login-text">Login</h2>
            <img src={mainLogo} alt="suprkid logo" />
          </div>
          <div id="login-middle-border">
          </div>
          <div className="center-login">
          <label className="login-label" htmlFor="email">Email ID</label>
              <input type="email" name="email" className="login-inp" onChange={handelChange} />
              <label className="login-label" htmlFor="pass">Password</label>
              <input type="password" name="password" className="login-inp" onChange={handelChange} />
              <a className="login-forgot" href="/">Forgot Password?</a>
          </div>
          <div className="bottom-login">
            <input className="login-btn" type="button" value="Login" onClick={showData}/>
          </div>
        </div>
      </div>
    </>
  );
};
export default Login;