import React from 'react'

export default function Notifications() {
  return (
    <div>Notifications</div>
  )
}
