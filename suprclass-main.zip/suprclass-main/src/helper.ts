import axios, { AxiosInstance } from "axios";

const uri: string = "https://suprkid-backend-dev.herokuapp.com/API/V1/";
// const uri: string = "http://localhost:5500/API/V1/";

const axiosinstance = axios.create({
  baseURL: uri,
  withCredentials: false,
  headers: {
    "Content-Type": "application/json",
  },
});

export { axiosinstance as axios };
