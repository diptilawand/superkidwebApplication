import axios, { AxiosResponse } from "axios";

const uri =
  process.env.NODE_ENV == "development"
    ? process.env.REACT_APP_DEV_URL
    : process.env.REACT_APP_URL;

let token = localStorage.getItem("refToken");
const instance = axios.create({
  baseURL: uri,
  headers: {
    Authorization: "Bearer " + token,
  },
});

// const responseBody = (response: AxiosResponse) => response.data;

export const call = {
  get: async (url: string) => await await instance.get(url),
  post: async (url: string, body: any) => await instance.post(url, body),
  put: async (url: string, body: any) => await instance.put(url, body),
  delete: async (url: string) => await instance.delete(url),
};
