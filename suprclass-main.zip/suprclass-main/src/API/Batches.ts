import { call } from "../helpers/axiosInterceptor";

const getBatches = async () => {
  try {
    const { data } = await call.get("batch");
    return data;
  } catch (e) {
    console.log(e);
  }
};

const createBatche = async (payload: any) => {
  try {
    const { data } = await call.post("batch", payload);
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getNewBatcheID = async (course) => {
  try {
    console.log(course);
    const { data } = await call.get(`batch/get/id/${course}`);
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getAdminbatches = async (id) => {
  const { data } = await call.get(`batch/search/admin-batch/${id}`);
  return data;
};

const updateBatch = async (payload: any) => {
  try {
    const { data } = await call.post("batch/update", payload);
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getBatchesBysearch = async (query) => {
  try {
    const { data } = await call.get(`batch/search/${query}`);
    return data;
  } catch (e) {
    console.log(e);
  }
};

export {
  getBatches,
  getNewBatcheID,
  createBatche,
  updateBatch,
  getBatchesBysearch,
  getAdminbatches,
};
