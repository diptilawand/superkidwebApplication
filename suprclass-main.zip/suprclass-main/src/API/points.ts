import { call } from "../helpers/axiosInterceptor";

const getAllPoints = async () => {
  try {
    const { data } = await call.get("card/list");
    return data;
  } catch (e) {
    console.log(e);
  }
};

const createPoints = async (payload: any) => {
  try {
    const { data } = await call.post("card", { ...payload });
    return data;
  } catch (e) {
    console.log(e);
  }
};

const updatePoints = async (payload: any) => {
  try {
    const { data } = await call.post("card/update", { ...payload });
    return data;
  } catch (e) {
    console.log(e);
  }
};

const allocateCard = async (payload: any) => {
  try {
    const { data } = await call.post("userPoints", { ...payload });
    return data;
  } catch (e) {
    console.log(e);
  }
};

export { getAllPoints, createPoints, updatePoints, allocateCard };
