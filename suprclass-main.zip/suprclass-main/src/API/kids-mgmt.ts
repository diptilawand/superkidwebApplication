import { call } from "../helpers/axiosInterceptor";

const getAllStudents = async () => {
  const { data } = await call.get("user");
  return data;
};

const createStudent = async (payload: any) => {
  const { data } = await call.post("user/create/admin", { ...payload });

  return data;
};

const updateKid = async (payload: any) => {
  const { data } = await call.post("user/update", { ...payload });
  return data;
};

const getKidsBysearch = async (query) => {
  const { data } = await call.get(`user/search/${query}`);
  return data;
};

export { getAllStudents, createStudent, updateKid, getKidsBysearch };
