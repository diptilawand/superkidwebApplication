import axios from "axios";
const uri =
  process.env.NODE_ENV == "development"
    ? process.env.REACT_APP_DEV_URL
    : process.env.REACT_APP_URL;

const uploadPointsLogo = async (payload: any) => {
  try {
    const { data } = await axios.post(uri + "upload", payload, {
      headers: {
        "Content-Type": "multipart/form-data; boundary=file",
      },
    });
    return data;
  } catch (e) {
    console.log(e);
  }
};

export { uploadPointsLogo };
