import { call } from "../helpers/axiosInterceptor";

const getCourseFillDetails = async () => {
  try {
    const { data } = await call.get("interests");

    return data;
  } catch (e) {
    console.log(e);
  }
};

const createCourse = async (payload: any) => {
  try {
    const { data } = await call.post("course/create", { ...payload });

    return data;
  } catch (e) {
    console.log(e);
  }
};

const getCourses = async () => {
  try {
    const { data } = await call.get("course/list");
    return data;
  } catch (e) {
    console.log(e);
  }
};

const updateCourse = async (payload: any) => {
  try {
    const { data } = await call.post("course/update", { ...payload });
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getCoursesById = async (id: any) => {
  try {
    const { data } = await call.get(`course/list/${id}`);
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getCoursesBysearch = async (query: any) => {
  try {
    const { data } = await call.get(`course/search/${query}`);
    return data;
  } catch (e) {
    console.log(e);
  }
};

export {
  getCourseFillDetails,
  createCourse,
  getCourses,
  getCoursesById,
  updateCourse,
  getCoursesBysearch,
};
