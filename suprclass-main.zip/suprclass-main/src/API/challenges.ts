import { call } from "../helpers/axiosInterceptor";

const getChallenges = async () => {
  try {
    const { data } = await call.get(`challenge/read`);
    return data;
  } catch (e) {
    console.log(e);
    return [];
  }
};

const createChallenge = async (data: any) => {
  try {
    const res = await call.post("challenge/", { data });
    console.log(res);
  } catch (e) {
    console.log(e);
  }
};

const updateChallenge = async (data: any) => {
  try {
    console.log("updating challenge", data.title);
    const res = await call.put("challenge/", { data });
    console.log(res);
  } catch (e) {
    console.log(e);
  }
};

export { getChallenges, createChallenge, updateChallenge };
