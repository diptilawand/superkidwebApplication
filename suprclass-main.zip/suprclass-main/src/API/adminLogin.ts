import { call } from "../helpers/axiosInterceptor";

async function AdminLogin(userData: any) {
  const { data } = await call.post("admin/login", userData);
  return data;
}

export default AdminLogin;
