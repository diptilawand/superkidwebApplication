import { call } from "../helpers/axiosInterceptor";

const getEvents = async () => {
  try {
    const { data } = await call.get(`event/read`);
    return data;
  } catch (e) {
    console.log(e);
    return [];
  }
};

const createEvent = async (data: any) => {
  try {
    const res = await call.post("event/", { data });
    console.log(res);
  } catch (e) {
    console.log(e);
  }
};

const updateEvent = async (data: any) => {
  try {
    const res = await call.put("event/", { data });
    console.log(res);
  } catch (e) {
    console.log(e);
  }
};

export { getEvents, createEvent, updateEvent };
