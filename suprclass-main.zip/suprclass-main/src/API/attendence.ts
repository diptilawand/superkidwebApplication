import { call } from "../helpers/axiosInterceptor";

const addAttendence = async (payload: any) => {
  try {
    const { data } = await call.post("attendence", { ...payload });
    return data;
  } catch (e) {
    console.log(e);
  }
};

const getAttendence = async (batch_id: any, payload: any) => {
  try {
    const { data } = await call.post(`attendence/list/${batch_id}`, {
      ...payload,
    });
    return data;
  } catch (e) {
    console.log(e);
  }
};

const unMarkAttendence = async (_id: any, user: any) => {
  try {
    const { data } = await call.get(`attendence/unmark/${_id}/${user}`);
    return data;
  } catch (e) {
    console.log(e);
  }
};

export { addAttendence, getAttendence, unMarkAttendence };
