import React from "react";
import { SideBar } from "../../components";

function Home() {
  return <div className="home">{/* <SideBar /> */}</div>;
}

export default Home;
