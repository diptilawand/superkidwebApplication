export default interface LoginMessage {
  message?: String;
}

export interface LoginData {
  email?: String;
  password?: String;
}
