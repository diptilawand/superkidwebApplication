export interface LocationProps {
  location?: string;
}
